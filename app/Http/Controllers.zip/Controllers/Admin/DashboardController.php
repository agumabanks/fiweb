<?php

namespace App\Http\Controllers\Admin;
// <?php

// namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Transaction;
use App\Models\UserLoan;
use App\Models\LoanPayment;
use App\Models\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;









use App\CentralLogics\Helpers;
// use App\Http\Controllers\Controller;
use App\Models\EMoney;
// use App\Models\Transaction;
use App\Models\User;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
// use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
// use Illuminate\Support\Facades\DB;






class DashboardController extends Controller
{
     public function __construct(
        private User        $user,
        private EMoney      $eMoney,
        private Transaction $transaction
    )
    {
    }
     public function settings(): View|Factory|Application
    {
        return view('admin-views.settings');
    }
    
       public function settingsUpdate(Request $request): RedirectResponse
    {
        $request->validate([
            'f_name' => 'required',
            'l_name' => 'required',
            'phone' => 'required',
        ]);

        $admin = $this->user->find(auth('user')->id());
        $admin->f_name = $request->f_name;
        $admin->l_name = $request->l_name;
        $admin->email = $request->email;
        $admin->phone = $request->phone;
        $admin->image = $request->has('image') ? Helpers::update('admin/', $admin->image, 'png', $request->file('image')) : $admin->image;
        $admin->save();
        Toastr::success(translate('Admin updated successfully!'));
        return back();
    }
    
    public function dashboard()
    {
        // Key metrics
        $totalLoansDisbursed = UserLoan::sum('amount'); // Total loans disbursed
        $totalRepayments = LoanPayment::sum('amount'); // Total repayments
        $totalOverdueLoans = UserLoan::where('status', '<>', 2) // Loans not fully paid
            ->where('due_date', '<', now()) // Past due date
            ->sum('final_amount'); // Total overdue loan amount

        // New clients registered today
        $newClientsToday = Client::whereDate('created_at', now())->count();

        // Balance calculation (used, unused, and total earned)
        $usedBalance = UserLoan::sum('amount'); // Example calculation for used balance
        $unusedBalance = LoanPayment::sum('amount'); // Example calculation for unused balance
        $totalEarned = $usedBalance * 0.05; // Example calculation for total earned (5% fee on used balance)

        // Define balance data
        $balance = [
            'total_balance' => $usedBalance + $unusedBalance,
            'used_balance' => $usedBalance,
            'unused_balance' => $unusedBalance,
            'total_earned' => $totalEarned, // Adding total_earned to the array
        ];

        // Performance Data
        $monthlyLoanData = $this->getMonthlyLoanData();
        $topAgents = $this->getTopPerformingAgents(); // Correctly define $topAgents
        $topCustomers = $this->getTopCustomers(); // Fetch top customers
        $topTransactions = $this->getTopTransactions(); // Fetch top transactions

        // Agent Performance & Loan Collection Analytics
        $agentLoanCollections = $this->getAgentLoanCollections();

        // Delinquency Analysis (Risk and Loan Aging)
        $loanAging = $this->getLoanAging();
        
        // dd($topAgents); // Add this line temporarily to debug


        // Pass all data to the view
        return view('admin-views.dashboard', compact(
            'balance', // Pass the balance array to the view
            'totalLoansDisbursed',
            'totalRepayments',
            'totalOverdueLoans',
            'newClientsToday',
            'monthlyLoanData',
            'topAgents', // Pass topAgents correctly to the view
            'topCustomers', // Pass topCustomers
            'topTransactions', // Pass topTransactions
            'agentLoanCollections',
            'loanAging'
        ));
    }

    // Monthly loan disbursement and repayment data
    private function getMonthlyLoanData()
    {
        $loanData = [];
        for ($i = 1; $i <= 12; $i++) {
            $loanData['disbursed'][] = UserLoan::whereMonth('created_at', $i)->sum('amount');
            $loanData['repaid'][] = LoanPayment::whereMonth('payment_date', $i)->sum('amount');
        }
        return $loanData;
    }

    // Top performing agents based on loan disbursement and collection
    private function getTopPerformingAgents()
    {
        return DB::table('users')
            ->join('user_loans', 'users.id', '=', 'user_loans.user_id')
            ->select('users.l_name', DB::raw('SUM(user_loans.amount) as total_disbursed'))
            ->groupBy('users.id')
            ->orderByDesc('total_disbursed')
            ->take(5) // Top 5 agents
            ->get();
    }

    // Top performing customers (based on transactions)
    // private function getTopCustomers()
    // {
    //     return DB::table('clients')
    //         ->join('transactions', 'clients.id', '=', 'transactions.client_id')
    //         ->select('clients.name', DB::raw('SUM(transactions.amount) as total_spent'))
    //         ->groupBy('clients.id')
    //         ->orderByDesc('total_spent')
    //         ->take(5) // Top 5 customers
    //         ->get();
    // }
    // Top performing customers (based on loan repayments)
   private function getTopCustomers()
{
    return DB::table('clients')
        ->join('loan_payments', 'clients.id', '=', 'loan_payments.client_id')
        ->select('clients.name', DB::raw('SUM(loan_payments.amount) as total_spent')) // Correct column alias
        ->groupBy('clients.id')
        ->orderByDesc('total_spent')
        ->take(5) // Top 5 customers
        ->get();
}



   // Top loan payments (based on amount paid)
private function getTopTransactions()
{
    return LoanPayment::orderByDesc('amount') // Order by the amount in descending order
        ->take(5) // Limit the results to the top 5 payments
        ->get();
}


// Fetch top performing agents based on loan disbursements
// private function getTopPerformingAgents()
// {
//     return DB::table('users')
//         ->join('user_loans', 'users.id', '=', 'user_loans.user_id')
//         ->select('users.l_name', DB::raw('SUM(user_loans.amount) as total_disbursed'))
//         ->groupBy('users.id')
//         ->orderByDesc('total_disbursed')
//         ->take(5) // Limit to top 5 agents
//         ->get();
// }


    // Agent Loan Collection Performance: Total disbursed, expected daily collection, and total collected
    private function getAgentLoanCollections()
    {
        return DB::table('users')
            ->join('user_loans', 'users.id', '=', 'user_loans.user_id')
            ->select(
                'users.l_name',
                DB::raw('SUM(user_loans.amount) as total_loan_amount'),
                DB::raw('SUM(user_loans.per_installment) as expected_daily_collection'),
                DB::raw('SUM(user_loans.paid_amount) as total_collected')
            )
            ->groupBy('users.id')
            ->get();
    }

    // Loan Aging and Risk Analytics (Analyze overdue loans)
    private function getLoanAging()
    {
        return [
            '30_days' => UserLoan::where('due_date', '<', now()->subDays(30))->count(),
            '60_days' => UserLoan::where('due_date', '<', now()->subDays(60))->count(),
            '90_days' => UserLoan::where('due_date', '<', now()->subDays(90))->count(),
        ];
    }
}

