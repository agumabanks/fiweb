<?php

 
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Agent;
use App\Models\Loan;
use App\Models\Payment;
use App\Models\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class AdminReportController extends Controller
{
    public function index(Request $request)
    {
        // Get the selected period from the request, default is 'daily'
        $period = $request->input('period', 'daily');

        // Set date ranges based on the selected period
        $startDate = Carbon::today();
        $endDate = Carbon::today();

        if ($period === 'weekly') {
            $startDate = Carbon::now()->startOfWeek();
            $endDate = Carbon::now()->endOfWeek();
        } elseif ($period === 'monthly') {
            $startDate = Carbon::now()->startOfMonth();
            $endDate = Carbon::now()->endOfMonth();
        }

        // Fetch financial summary data
        $financialSummary = $this->getFinancialSummary($startDate, $endDate);

        // Fetch agent report data
        $agentReportData = $this->getAgentReportData($startDate, $endDate);

        // Fetch loan statistics data
        $loanStatistics = $this->getLoanStatistics($startDate, $endDate);

        // Fetch key highlights data
        $keyHighlights = $this->getKeyHighlights($startDate, $endDate);

        // Page title
        $pageTitle = ucfirst($period) . " Report";

        // Return the view with all the data
        return view('admin-views.report.index', compact(
            'financialSummary',
            'agentReportData',
            'loanStatistics',
            'keyHighlights',
            'pageTitle'
        ));
    }

    private function getFinancialSummary($startDate, $endDate)
    {
        $cashInflow = Payment::whereBetween('created_at', [$startDate, $endDate])->sum('amount');
        $cashOutflow = DB::table('expenses')->whereBetween('created_at', [$startDate, $endDate])->sum('amount');
        $loanProcessingFees = Loan::whereBetween('created_at', [$startDate, $endDate])->sum('processing_fee');
        $openingBalance = $this->getOpeningBalance($startDate);
        $closingBalance = $openingBalance + $cashInflow - $cashOutflow;
        $cashouts = DB::table('cashouts')->whereBetween('created_at', [$startDate, $endDate])->sum('amount');
        $expenses = DB::table('expenses')
            ->select('category', DB::raw('SUM(amount) as total'))
            ->whereBetween('created_at', [$startDate, $endDate])
            ->groupBy('category')
            ->get();

        return compact('cashInflow', 'cashOutflow', 'loanProcessingFees', 'openingBalance', 'closingBalance', 'cashouts', 'expenses');
    }

    private function getOpeningBalance($startDate)
    {
        // Calculate the opening balance based on the last known closing balance before the start date
        $lastBalance = DB::table('balances')->where('created_at', '<', $startDate)->orderBy('created_at', 'desc')->value('balance');
        return $lastBalance ?? 0;
    }

    private function getAgentReportData($startDate, $endDate)
    {
        $agents = Agent::with(['clients' => function ($query) use ($startDate, $endDate) {
            $query->with(['loanPayments' => function ($query) use ($startDate, $endDate) {
                $query->whereBetween('created_at', [$startDate, $endDate]);
            }]);
        }])->get();

        $agentPerformance = [];
        $totals = [
            'total_clients' => 0,
            'total_money_out' => 0,
            'total_expected_daily' => 0,
            'total_amount_collected' => 0,
            'total_performance' => 0
        ];

        foreach ($agents as $agent) {
            $clientCount = $agent->clients->count();
            $totalMoneyOut = $agent->clients->sum('loan_amount');
            $expectedDaily = $agent->clients->sum('expected_payment');
            $amountCollected = $agent->clients->sum(function ($client) {
                return $client->loanPayments->sum('amount');
            });

            $performancePercentage = $expectedDaily > 0 ? ($amountCollected / $expectedDaily) * 100 : 0;

            $agentPerformance[] = [
                'agent' => $agent,
                'client_count' => $clientCount,
                'total_money_out' => $totalMoneyOut,
                'expected_daily' => $expectedDaily,
                'amount_collected' => $amountCollected,
                'performance_percentage' => $performancePercentage,
            ];

            $totals['total_clients'] += $clientCount;
            $totals['total_money_out'] += $totalMoneyOut;
            $totals['total_expected_daily'] += $expectedDaily;
            $totals['total_amount_collected'] += $amountCollected;
        }

        $totals['total_performance'] = $totals['total_expected_daily'] > 0
            ? ($totals['total_amount_collected'] / $totals['total_expected_daily']) * 100
            : 0;

        return compact('agentPerformance', 'totals');
    }

    private function getLoanStatistics($startDate, $endDate)
    {
        $loansDisbursed = Loan::select('plan_id', DB::raw('SUM(amount) as total_amount'))
            ->whereBetween('created_at', [$startDate, $endDate])
            ->groupBy('plan_id')
            ->get();

        $totalRepayments = Payment::whereBetween('created_at', [$startDate, $endDate])->sum('amount');

        $delinquencyMetrics = [
            'overdueLoans' => Loan::where('status', 'overdue')->count(),
            'delinquencyRate' => Loan::where('status', 'overdue')->count() / Loan::count() * 100,
            'aging30Days' => Loan::where('status', 'overdue')->where('days_overdue', '>=', 30)->count(),
            'aging60Days' => Loan::where('status', 'overdue')->where('days_overdue', '>=', 60)->count(),
            'aging90Days' => Loan::where('status', 'overdue')->where('days_overdue', '>=', 90)->count(),
        ];

        $interestEarned = Loan::whereBetween('created_at', [$startDate, $endDate])->sum('interest');

        return compact('loansDisbursed', 'totalRepayments', 'delinquencyMetrics', 'interestEarned');
    }

    private function getKeyHighlights($startDate, $endDate)
    {
        $newClientsCount = Client::whereBetween('created_at', [$startDate, $endDate])->count();
        $totalRepayments = Payment::whereBetween('created_at', [$startDate, $endDate])->sum('amount');
        $improvedDelinquencyRate = $this->calculateDelinquencyImprovement();

        $topAgents = Agent::with(['payments' => function ($query) use ($startDate, $endDate) {
            $query->whereBetween('created_at', [$startDate, $endDate]);
        }])
        ->get()
        ->sortByDesc(function ($agent) {
            return $agent->payments->sum('amount');
        })
        ->take(3);

        return compact('newClientsCount', 'totalRepayments', 'improvedDelinquencyRate', 'topAgents');
    }

    private function calculateDelinquencyImprovement()
    {
        // Implement your logic for calculating improvement in delinquency rate here
        return 5; // Placeholder value
    }
}


// namespace App\Http\Controllers;

// use Illuminate\Http\Request;
// use App\Models\User; // Assuming agents are stored as users
// use App\Models\Client;
// use App\Models\LoanPayment;
// use App\Models\LoanPaymentInstallment;
// use Carbon\Carbon;


// // class AgentReportController extends Controller

// class AdminReportController extends Controller
// {
//     /**
//      * Display the report of a specific agent for a given day. AdminReportController
//      *
//      * @param \Illuminate\Http\Request $request
//      * @param int $agentId
//      * @return \Illuminate\View\View
//      */
//     public function index(Request $request, $agentId)
//     {
//         // Define the current date
//         $today = Carbon::today();

//         // Find the agent by their ID and role
//         $agent = User::where('role', 'agent')->findOrFail($agentId);

//         // Fetch clients assigned to the agent
//         $clients = Client::where('added_by', $agentId)->get();

//         // Initialize counters and totals
//         $totalClients = $clients->count();
//         $totalClientsPaid = 0;
//         $totalClientsUnpaid = 0;
//         $totalClientsAdvancePaid = 0;
//         $totalLoanAmount = 0;
//         $totalCollectedToday = 0;

//         foreach ($clients as $client) {
//             // Fetch loan payments made today by the client
//             $paymentsToday = LoanPayment::where('client_id', $client->id)
//                 ->whereDate('created_at', $today)
//                 ->get();

//             $totalPaidToday = $paymentsToday->sum('amount');
//             $expectedPaymentToday = $client->expected_payment ?? 0; // Ensure this field exists or default to 0

//             // Accumulate loan amounts (assuming client loan amount is stored in 'loan_amount')
//             $totalLoanAmount += $client->loan_amount ?? 0;

//             // Calculate totals
//             $totalCollectedToday += $totalPaidToday;

//             if ($totalPaidToday >= $expectedPaymentToday && $totalPaidToday > 0) {
//                 $totalClientsPaid++;
//             } elseif ($totalPaidToday > $expectedPaymentToday) {
//                 $totalClientsAdvancePaid++;
//             } else {
//                 $totalClientsUnpaid++;
//             }
//         }

//         // Pass data to the view
//         return view('admin-views.agent.agent-report', compact(
//             'agent',
//             'totalClients',
//             'totalClientsPaid',
//             'totalClientsUnpaid',
//             'totalClientsAdvancePaid',
//             'totalLoanAmount',
//             'totalCollectedToday'
//         ));
//     }

//     /**
//      * Generate agent performance report for a given date range.
//      *
//      * @param array $dateRange
//      * @return array
//      */
//     private function getAgentPerformance($dateRange)
//     {
//         // Fetch agents with client counts and total money out
//         $agents = User::where('role', 'agent')->get();

//         $agentPerformance = [];

//         foreach ($agents as $agent) {
//             // Total number of clients assigned to this agent
//             $clientsTotal = Client::where('added_by', $agent->id)->count();

//             // Total number of clients with payments made during the date range by this agent
//             $clientsPaidToday = LoanPayment::where('agent_id', $agent->id)
//                 ->whereBetween('created_at', [$dateRange['start'], $dateRange['end']])
//                 ->distinct('client_id')
//                 ->count();

//             $clientsUnpaidToday = $clientsTotal - $clientsPaidToday;

//             // Total number of clients who have paid in advance today by this agent
//             $clientsPaidAdvanceToday = LoanPaymentInstallment::where('agent_id', $agent->id)
//                 ->whereBetween('created_at', [$dateRange['start'], $dateRange['end']])
//                 ->where('status', 'paid')
//                 ->whereColumn('install_amount', '>', 'loan_payment_installments.install_amount')
//                 ->distinct('client_id')
//                 ->count();

//             // Add agent data to the agentPerformance array
//             $agentPerformance[] = [
//                 'agent_name'               => $agent->f_name . ' ' . $agent->l_name,
//                 'clientsTotal'             => $clientsTotal,
//                 'clientsPaidToday'         => $clientsPaidToday,
//                 'clientsUnpaidToday'       => $clientsUnpaidToday,
//                 'clientsPaidAdvanceToday'  => $clientsPaidAdvanceToday,
//             ];
//         }

//         return [
//             'agentPerformance' => $agentPerformance,
//         ];
//     }
// }
