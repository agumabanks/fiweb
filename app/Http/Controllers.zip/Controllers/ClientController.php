<?php

namespace App\Http\Controllers;

use App\Models\Client;
use Illuminate\Http\Request;

use App\Models\LoanOffer;
use App\Models\LoanPlan;
use App\Models\UserLoan;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
use App\Models\Guarantor;
use App\CentralLogics\Helpers;
use Stevebauman\Location\Facades\Location;

use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\View\Factory;
use Illuminate\Contracts\View\View;
use App\Models\LoanPaymentInstallment;

use App\Models\SanaaCard;
use Illuminate\Support\Facades\DB;
use PDF;

use App\Models\LoanPayment;
use App\Models\Branch;

use Carbon\Carbon;

 

use Brian2694\Toastr\Facades\Toastr;

class ClientController extends Controller
{
    public function getClientsWhoPaidToday(Request $request): JsonResponse
        {
            // Get today's date
            $today = Carbon::today();
        
            // Determine the number of results per page (default to 20 if not specified)
            $perPage = $request->input('per_page', 20);
        
            // Fetch clients who have made payments today, using pagination
            $clients = Client::whereHas('loanPayments', function ($query) use ($today) {
                $query->whereDate('created_at', $today);
            })->paginate($perPage);
        
            // Return the clients as a JSON response
            return response()->json([
                'status' => 'success',
                'message' => 'Clients who have made payments today retrieved successfully.',
                'data' => $clients->items(), // Returns the paginated items
                'current_page' => $clients->currentPage(),
                'per_page' => $clients->perPage(),
                'total' => $clients->total(),
                'last_page' => $clients->lastPage(),
            ], 200);
        } 








    
   public function getClientsWhoHaventPaidToday(Request $request): JsonResponse
    {
        // Get today's date
        $today = Carbon::today();
    
        // Set the pagination limit, defaulting to 20 if not provided
        $perPage = $request->input('per_page', 20);
    
        // Get clients who haven't made any payments today with pagination
        $clients = Client::whereDoesntHave('loanPayments', function ($query) use ($today) {
            $query->whereDate('created_at', $today);
        })->paginate($perPage);
    
        // Return the paginated clients as a JSON response
        return response()->json([
            'status' => 'success',
            'message' => 'Clients who have not paid today retrieved successfully.',
            'data' => $clients->items(),
            'current_page' => $clients->currentPage(),
            'per_page' => $clients->perPage(),
            'total' => $clients->total(),
            'last_page' => $clients->lastPage(),
        ], 200);
    }
    
    /**
     * Generate the Agents Report.
     *
     * @param array $dateRange
     * @return array
     */
    private function getAgentPerformance($dateRange)
    {
        // Fetch agents with client counts and total money out
        $agents = User::join('clients', 'users.id', '=', 'clients.added_by')
            ->select(
                'users.id',
                'users.f_name',
                'users.l_name',
                DB::raw('COUNT(clients.id) as client_count'),
                DB::raw('SUM(clients.credit_balance) as total_money_out')
            )
            ->groupBy('users.id', 'users.f_name', 'users.l_name')
            ->get();

        $agentPerformance = [];

        $totalClients = 0;
        $totalMoneyOut = 0;
        $totalAmountCollected = 0;
        $totalExpectedDaily = 0;

        foreach ($agents as $agent) {
            // Calculate expected daily amount from total money out
            // Assuming 30 days in a month for calculation
            $agent->expected_daily = $agent->total_money_out / 30;

            // Calculate amount collected from cleared payment installments within the date range
            $agent->amount_collected = LoanPayment::where('agent_id', $agent->id)
                ->whereBetween('created_at', [$dateRange['start'], $dateRange['end']])
                ->sum('amount');

            // Calculate performance percentage
            $expectedTotal = $agent->expected_daily * 30; // This equals total_money_out
            if ($expectedTotal > 0) {
                $agent->performance_percentage = ($agent->amount_collected / $expectedTotal) * 100;
            } else {
                $agent->performance_percentage = 0;
            }

            // Update totals
            $totalClients += $agent->client_count;
            $totalMoneyOut += $agent->total_money_out;
            $totalAmountCollected += $agent->amount_collected;
            $totalExpectedDaily += $agent->expected_daily;

            // Prepare data for agentPerformance array
            $agentPerformance[] = [
                'agent' => $agent,
                'client_count' => $agent->client_count,
                'total_money_out' => $agent->total_money_out,
                'expected_daily' => $agent->expected_daily,
                'amount_collected' => $agent->amount_collected,
                'performance_percentage' => $agent->performance_percentage,
            ];
        }

        // Calculate total performance percentage
        if ($totalMoneyOut > 0) {
            $totalPerformance = ($totalAmountCollected / $totalMoneyOut) * 100;
        } else {
            $totalPerformance = 0;
        }

        // Prepare totals array
        $totals = [
            'total_clients' => $totalClients,
            'total_money_out' => $totalMoneyOut,
            'total_amount_collected' => $totalAmountCollected,
            'total_expected_daily' => $totalExpectedDaily,
            'total_performance' => $totalPerformance,
        ];

        return [
            'agentPerformance' => $agentPerformance,
            'totals' => $totals,
        ];
    }
    public function agentTransactions(){
        $agentReportData = $this->getAgentPerformance($dateRange);
        $today = Carbon::today();
        // Real-Time Installment Payments: Eager load agent and client details using LoanPayment model
        $installmentPayments = LoanPayment::with(['agent', 'client']) // Load both agent and client details
            ->orderBy('created_at', 'desc') // Order by the latest created records
            ->take(50) // Limit to 50 records
            ->get();
            
            // real-Time-Payments.blade.php
            return view('admin-views.reports.real-Time-Payments', compact('installmentPayments','agentReportData'));
    }
    
    /**
     * Determine the date range based on the selected period.
     *
     * @param string $period
     * @return array
     */
    private function getDateRange($period)
    {
        switch ($period) {
            case 'weekly':
                $startDate = Carbon::now()->startOfWeek();
                $endDate = Carbon::now()->endOfWeek();
                break;
            case 'monthly':
                $startDate = Carbon::now()->startOfMonth();
                $endDate = Carbon::now()->endOfMonth();
                break;
            default: // daily
                $startDate = Carbon::now()->startOfDay();
                $endDate = Carbon::now()->endOfDay();
                break;
        }
        return ['start' => $startDate, 'end' => $endDate];
    }
    
     public function agentDash(Request $request)
{
    $today = Carbon::today();
    $period = $request->input('period', 'daily'); // Options: daily, weekly, monthly
    $dateRange = $this->getDateRange($period);
    $agentReportData = $this->getAgentPerformance($dateRange);


    // Total Installments Collected Today
    $totalInstallmentsCollectedToday = LoanPaymentInstallment::whereDate('date', $today)
        ->where('status', 'paid')
        ->count();

    // Total Amount Collected Today
    $totalAmountCollectedToday = LoanPaymentInstallment::whereDate('date', $today)
        ->where('status', 'paid')
        ->sum('install_amount');

    // Total Overdue Installments
    $totalOverdueInstallments = LoanPaymentInstallment::whereDate('date', '<', $today)
        ->where('status', 'overdue')
        ->count();

    // Total Active Loans (Running loans)
    $totalActiveLoans = UserLoan::where('status', 1)->count();

    // New Clients Added Today
    $newClientsToday = Client::whereDate('created_at', $today)->count();

    // Agent Financial Summary: Eager load agent details
    $agentTransactions = LoanPayment::with('agent') // Load agent details
        ->select('agent_id', DB::raw('SUM(amount) as total_amount'), DB::raw('COUNT(id) as transaction_count'))
        ->whereDate('payment_date', $today)
        ->groupBy('agent_id')
        ->get();



// Real-Time Installment Payments: Eager load agent and client details using LoanPayment model
    $installmentPayments = LoanPayment::with(['agent', 'client']) // Load both agent and client details
        ->orderBy('created_at', 'desc') // Order by the latest created records
        ->take(50) // Limit to 50 records
        ->get();


    // Loans Overview: Active, Paid, and Overdue Loans Managed by Agents
    $activeLoans = UserLoan::where('status', 1)->get();  // Active loans
    $paidLoans = UserLoan::where('status', 2)->get();    // Paid loans

    // Fetch loans with overdue installments
    $overdueLoans = UserLoan::whereHas('loanPaymentInstallments', function ($query) {
        $query->where('status', 'overdue');
    })->get();

    // Client Overview: Clients assigned to each agent
    $clients = Client::with(['userLoans' => function ($query) {
        $query->select('client_id', 'status', 'amount', 'next_installment_date');
    }])->get();

    return view('admin-views.reports.agent-report-today', compact(
        'totalInstallmentsCollectedToday', 'totalAmountCollectedToday', 'totalOverdueInstallments',
        'totalActiveLoans', 'newClientsToday', 'agentTransactions', 'installmentPayments', 
        'activeLoans', 'paidLoans', 'overdueLoans', 'clients','agentReportData'
    ));
}
    public function getUserAgentByPhone(Request $request)
    {
        // Validate the request input
        $request->validate([
            'phone' => 'required|string',
        ]);

        $phone = $request->input('phone');

        // Query the user by phone number
        $user = User::where('phone', $phone)->first();

        if ($user) {
            // Return the user data as JSON
            return response()->json($user);
        } else {
            // Return a 404 error if user not found
            return response()->json(['error' => 'User not found'], 404);
        }
    }
    
    public function search(Request $request)
    {
        // Get query parameters
        $searchQuery = $request->input('q'); // For general search (name, ID)
        $sortBy = $request->input('sortBy', 'id'); // Default to sorting by 'id'
        $sortOrder = $request->input('sortOrder', 'asc'); // Default to ascending order
        $perPage = $request->input('perPage', 10); // Default to 10 results per page
    
        // Build the query
        $query = Client::query();
    
        // Search by name or ID (modify this based on your database columns)
        if ($searchQuery) {
            $query->where('name', 'like', '%' . $searchQuery . '%')
                  ->orWhere('id', 'like', '%' . $searchQuery . '%');
        }
    
        // Add filters (if any specific filtering is needed, e.g., by status)
        if ($request->has('status')) {
            $query->where('status', $request->input('status'));
        }
    
        // Apply sorting
        $query->orderBy($sortBy, $sortOrder);
    
        // Paginate the results
        $clients = $query->paginate($perPage);
    
        // Return the paginated result in JSON format
        return response()->json($clients);
    }

  
    
    

    
  


    
    public function agentReport()
            {
                // Fetch agents with client counts and total money out
                $agents = User::join('clients', 'users.id', '=', 'clients.added_by')
                    ->select(
                        'users.id',
                        'users.f_name',
                        'users.l_name',
                        \DB::raw('COUNT(clients.id) as client_count'),
                        \DB::raw('SUM(clients.credit_balance) as total_money_out')
                    )
                    ->groupBy('users.id', 'users.f_name', 'users.l_name')
                    ->get();
            
                // Initialize totals
                $totalClients = 0;
                $totalMoneyOut = 0;
                $totalAmountCollected = 0;
                $totalExpectedDaily = 0;
            
                foreach ($agents as $agent) {
                    // Calculate expected daily amount from total money out
                    $agent->expected_daily = $agent->total_money_out / 30;
            
                    // Calculate amount collected from cleared payment slots
                    $agent->amount_collected = LoanPaymentInstallment::where('agent_id', $agent->id)
                        ->where('status', 'cleared')
                        ->sum('install_amount');
            
                    // Calculate performance percentage
                    $expectedTotal = $agent->expected_daily * 30; // This equals total_money_out
                    if ($expectedTotal > 0) {
                        $agent->performance_percentage = ($agent->amount_collected / $expectedTotal) * 100;
                    } else {
                        $agent->performance_percentage = 0;
                    }
            
                    // Update totals
                    $totalClients += $agent->client_count;
                    $totalMoneyOut += $agent->total_money_out;
                    $totalAmountCollected += $agent->amount_collected;
                    $totalExpectedDaily += $agent->expected_daily; // Sum expected daily across all agents
                }
            
                // Calculate total performance percentage
                if ($totalMoneyOut > 0) {
                    $totalPerformance = ($totalAmountCollected / $totalMoneyOut) * 100;
                } else {
                    $totalPerformance = 0;
                }
            
                // Prepare totals array for the view
                $totals = [
                    'total_clients' => $totalClients,
                    'total_money_out' => $totalMoneyOut,
                    'total_amount_collected' => $totalAmountCollected,
                    'total_expected_daily' => $totalExpectedDaily, // Add this line
                    'total_performance' => $totalPerformance,
                ];
            
                return view('admin-views.reports.agent-report', compact('agents', 'totals'));
            }
   
//   printCard
  public function printCard($clientId)
{
    $client = Client::findOrFail($clientId);
    $card = SanaaCard::where('client_id', $clientId)->firstOrFail();

    // Generate HTML for both front and back sides, passing the $client variable
    $frontHtml = view('admin-views.clients.print-front', compact('client', 'card'))->render();
    $backHtml = view('admin-views.clients.print-back', compact('client', 'card'))->render();

    $combinedHtml = $frontHtml . '<div style="page-break-after: always;"></div>' . $backHtml;

    $customPaper = array(0,0,317.74,199.8);
    $pdf = PDF::loadHTML($combinedHtml)->setPaper($customPaper)->setWarnings(false);

    return $pdf->download('card_' . $client->id . '.pdf'); 
}
  
  
  
  

   
    public function edit($id)
    {
        // Fetch the client by ID
        $client = Client::findOrFail($id);
        $users = User::all();
    
        // Pass the client data to the view
        return view('admin-views.clients.edit', compact('client', 'users'));
    }
    

public function createClient(Request $request)
{
    $ip = env('APP_MODE') == 'live' ? $request->ip() : '61.247.180.82';
    $currentUserInfo = Location::get($ip);
    $users = User::all();

    // Retrieve all branches to display in the client creation form
    $branches = Branch::all();

    return view('admin-views.clients.create', compact('currentUserInfo', 'users', 'branches'));
}

  public function store(Request $request)
{ 
    // dd($request->all());
    // Add 'branch_id' to validation rules to ensure the client is linked to a branch.
    $validatedData = $request->validate([
        'name' => 'required|string|max:255',
        'email' => 'nullable|string|email|max:255|unique:clients',
        'phone' => 'required|string|max:255',
        'address' => 'nullable|string|max:255',
        'status' => 'required|string|max:255',
        'kyc_verified_at' => 'nullable|date',
        'dob' => 'nullable|date',
        'business' => 'nullable|string|max:255',
        'nin' => 'nullable|string|max:255',
        'recommenders' => 'nullable|json',
        'credit_balance' => 'required|numeric|min:0',
        'savings_balance' => 'required|numeric|min:0',
        'added_by' => 'nullable|string|max:255',
        'next_of_kin' => 'nullable|string|max:255',
        'branch_id' => 'required|uuid|exists:branches,branch_id', // Validate branch_id
    ]);

    // Generate email if it's not provided
    if (empty($validatedData['email'])) {
        // Create an email from the name (make it lowercase and remove any spaces)
        $validatedData['email'] = strtolower(str_replace(' ', '', $validatedData['name'])) . '@sanaa.co';
    }

    // Assign the branch ID from the request or the logged-in user if not provided
    if (!isset($validatedData['branch_id'])) {
        $validatedData['branch_id'] = auth()->user()->branch_id; // Assuming the user has a branch assigned
    }

    // Create the client with branch_id
    Client::create($validatedData);

    // Flash a success message
    return redirect()->route('admin.allclients')->with('success', 'Client added successfully.');
}


  // add guarantors
  
  
  public function addClientGuarantor(Request $request): JsonResponse
{
    try {
        // Handle file uploads
        $photoPath = $request->file('photo') ? $request->file('photo')->store('guarantors/photos', 'public') : null;
        $nationalIdPhotoPath = $request->file('national_id_photo') ? $request->file('national_id_photo')->store('guarantors/national_id_photos', 'public') : null;

        // Create the guarantor
        $guarantor = Guarantor::create([
            'name' => $request->input('name'),
            'nin' => $request->input('nin'),
            'phone_number' => $request->input('phone_number'),
            'address' => $request->input('address'),
            'relationship' => $request->input('client_relationship'),
            'job' => $request->input('job'),
            'photo' => $photoPath,
            'national_id_photo' => $nationalIdPhotoPath,
            'added_by' => $request->input('added_by'),
            'client_id' => $request->input('client_id'),
        ]);

        // Return success response with guarantor data
        return response()->json(response_formatter(DEFAULT_200, $guarantor, null), 200);
    } catch (\Exception $e) {
        // Handle any unexpected errors
        return response()->json(response_formatter(DEFAULT_500, null, 'An error occurred while adding the guarantor.'), 500);
    }
}

  
  
  
  
    public function addClientGuarantor10(Request $request): JsonResponse
    {
  
       
        $photoPath = $request->file('photo') ? $request->file('photo')->store('guarantors/photos', 'public') : null;
        $nationalIdPhotoPath = $request->file('national_id_photo') ? $request->file('national_id_photo')->store('guarantors/national_id_photos', 'public') : null;

        // Create the guarantor
        $guarantor = Guarantor::create([
            'name' => $request->name,
            'nin' => $request->nin,
            'photo' => $photoPath,
            'national_id_photo' => $nationalIdPhotoPath,
            'added_by' => $request->added_by,
            'client_id' => $request->client_id,
        ]);

        return response()->json(response_formatter(DEFAULT_200, $guarantor, null), 200);

    }

    public function agentClientDetails_old($agentId)
                {
                   
                    $queryParams = [];
                    $agent =        User::findOrFail($agentId);
                    // $clients =      Client::where('added_by', $agentId)->get();
                    $clientsQuery = Client::where('added_by', $agentId)->get(); // SanaaCard::query();
                    
                    
                    // get client details
                    $clientsData = [];
                    $clients = $clientsQuery->latest()->paginate(Helpers::pagination_limit())->appends($queryParams);
                
                    // Loop through the clients and collect the required data
                    foreach ($clients as $client) {
                        $clientGuarantorName = Guarantor::find($client->client_id);  
                        
                        $clientsData[] = [
                            'client' => $client,
                            'client_name' => $clientName ? $clientName->name : 'N/A',
                        ];
                    }
                
                    // Calculate total credit balance and total loan balance
                    $totalCreditBalance = $clients->sum('credit_balance');
                    $totalLoanBalance = $clients->sum('loan_balance');
                
                    return view('admin-views.reports.agentClientDetails', compact('agent', 'clients', 'totalCreditBalance', 'totalLoanBalance'));
        
          }
          
          
    public function agentClientDetails($agentId)
            {
                $queryParams = [];
                $agent = User::findOrFail($agentId);
            
                $clientsQuery = Client::where('added_by', $agentId); 
                $clients = $clientsQuery->latest()->paginate(Helpers::pagination_limit())->appends($queryParams);
            
                $clientsData = [];
            
                foreach ($clients as $client) {
                    // The main issue is here: You're trying to find a Guarantor by the client_id, 
                    // but client_id in the Guarantor model likely refers to the Client it's associated with. 
                    // You need to find the Guarantor based on the Client's id.
                    $clientGuarantor = Guarantor::where('client_id', $client->id)->first(); 
            
                    $clientsData[] = [
                        'client' => $client,
                        // Use the guarantor's name if found, otherwise 'N/A'
                        'guarantor_name' => $clientGuarantor ? $clientGuarantor->name : 'N/A', 
                    ];
                }
            
                $totalCreditBalance = $clients->sum('credit_balance');
                $totalLoanBalance = $clients->sum('loan_balance');
            
                return view('admin-views.reports.agentClientDetails', compact('agent', 'clients', 'totalCreditBalance', 'totalLoanBalance', 'clientsData')); 
            }
  
  public function show13($id)
    {
        // Fetch the client by ID
        $client = Client::findOrFail($id);
        
        $clientLoanPayment = LoanPayment::where();

        
    
        // Pass the client data to the view
        return view('admin-views.clients.profile', compact('client'));
    }
  
  
  
  // In your ClientController
    public function show($id)
{
    // Fetch the client by ID
    $client = Client::findOrFail($id);

    // Get the agent who added the client
    $agent = User::find($client->added_by);

    // Get all guarantors associated with this client
    $guarantors = Guarantor::where('client_id', $client->id)->get();

    // Get client loan history
    $clientLoanPayHistroy = LoanPayment::where('client_id', $client->id)
                            ->orderBy('created_at', 'desc') // Order by created_at in descending order (latest first)
                            ->get();

    // Client loans
    $clientLoans = UserLoan::where('client_id', $client->id)->get();

    // Get the client's branch
    $branch = Branch::find($client->branch_id);

    // Pass all the data to the view
    return view('admin-views.clients.profile', compact('client', 'agent', 'guarantors', 'clientLoanPayHistroy', 'clientLoans', 'branch'));
}





function generateUniquePAN() {
    do {
        // Generate a random 16-digit number
        $pan = '';
        for ($i = 0; $i < 4; $i++) {
            $pan .= str_pad(random_int(0, 5959), 4, '0', STR_PAD_LEFT);
        }
        
        // Check if the generated PAN already exists in the database
        $panExists = SanaaCard::where('pan', $pan)->exists();
    } while ($panExists); // Repeat if the PAN is not unique
    
    return $pan;
}



function generateSanaaCardData() 
    {
        // Fetch clients from the database
        $clients = Client::all();
    
        foreach ($clients as $client) {
            // Generate a unique PAN (Primary Account Number) - typically a 16-digit number
            $pan = $this-> generateUniquePAN();
    
            // Generate other card fields
            $cvv = str_pad(mt_rand(0, 999), 3, '0', STR_PAD_LEFT); // 3-digit CVV
            $iin = '123456'; // Issuer Identification Number (you may want to use your own logic)
            $expiryDate = now()->addYears(5)->toDateString(); // Card expiry 5 years from now
            $issueDate = now()->toDateString(); // Today's date as the issue date
            $balance = '0'; // Random balance for example
            $pinCode = bcrypt('1234'); // Example: bcrypt the PIN for security
            
            // Create a new SanaaCard entry
            SanaaCard::create([
                'client_id' => $client->id,
                'pan' => $pan,
                'cvv' => $cvv,
                'card_status' => 'active',
                'is_printed' => false, // Default to not printed
                'card_type' => 'phy',
                'issue_date' => $issueDate,
                'expiry_date' => $expiryDate,
                'balance' => $balance,
                'currency' => 'UGX', // Default to UGX
                'pin_code' => $pinCode,
                'emv_chip' => null, // Placeholder
                'magnetic_stripe_data' => null, // Placeholder
                'hologram' => null, // Placeholder
                'signature_panel' => null, // Placeholder
                'iin' => $iin,
                'nfc_enabled' => false,
            ]);
        }
    }

    public function update(Request $request, $id)
    {
        // Validate the request data
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:clients,email,' . $id, // Exclude current client from unique check
            'phone' => 'required|string|max:255',
            'address' => 'nullable|string|max:255',
            'status' => 'required|string|max:255',
            'kyc_verified_at' => 'nullable|date',
            'dob' => 'nullable|date',
            'business' => 'nullable|string|max:255',
            'nin' => 'nullable|string|max:255',
            'recommenders' => 'nullable|json',
            'credit_balance' => 'required|numeric|min:0',
            'savings_balance' => 'required|numeric|min:0',
            'added_by' => 'nullable|string|max:255',
            'next_of_kin' => 'nullable|string|max:255',
        ]);
    
        // Find the client by ID and update with validated data
        $client = Client::findOrFail($id);
        $client->update($validatedData);
    
        // Redirect to clients list with a success message
        return redirect()->route('admin.allclients')->with('success', 'Client updated successfully.');
    }


    public function index(): JsonResponse
    {
        
        $clients = Client::all();
        // return response()->json($clients);
        $customers = $customers->latest()->customer()->paginate(Helpers::pagination_limit())->appends($queryParams);

        return response()->json(response_formatter(DEFAULT_200, $clients, null), 200);
    }
    
    // agents clints
      //  get client profile 
   public function getAgentClient(Request $request): JsonResponse
    {
        $clients = Client::where('added_by', $request -> agentId)->get();
        return response()->json(response_formatter(DEFAULT_200, $clients, null), 200);
        
    }
    
    public function clientsCards(Request $request): Factory|View|Application
        {
            $pageTitle = 'All Clients Cards';
            $emptyMessage = 'No clients found';
        
            $queryParams = [];
            $search = $request->get('search');
            
            $clientsQuery = SanaaCard::query();
            
            if ($search) {
                $key = explode(' ', $search);
                $clientsQuery->where(function ($q) use ($key) {
                    foreach ($key as $value) {
                        $q->orWhere('name', 'like', "%{$value}%")
                          ->orWhere('nin', 'like', "%{$value}%")
                          ->orWhere('email', 'like', "%{$value}%")
                          ->orWhere('phone', 'like', "%{$value}%");
                    }
                });
                $queryParams['search'] = $search;
            }
        
            $clientsCardData = [];
            $clients = $clientsQuery->latest()->paginate(Helpers::pagination_limit())->appends($queryParams);
        
            // Loop through the clients and collect the required data
            foreach ($clients as $client) {
                $clientName = Client::find($client->client_id); // Fetch the user who added this client
                
                $clientsCardData[] = [
                    'client' => $client,
                    'client_name' => $clientName ? $clientName->name : 'N/A',
                ];
            }
        
            return view('admin-views.clients.clients-cards', compact('clientsCardData', 'search', 'pageTitle', 'emptyMessage', 'clients'));
        }

    
    // all clients
 
    public function clients(Request $request): Factory|View|Application
    {
        // $this -> generateSanaaCardData();
        $pageTitle = 'All Clients';
        $emptyMessage = 'No clients found';
    
        $queryParams = [];
        $search = $request->get('search');
        
        $clientsQuery = Client::query();
        
        if ($search) {
            $key = explode(' ', $search);
            $clientsQuery->where(function ($q) use ($key) {
                foreach ($key as $value) {
                    $q->orWhere('name', 'like', "%{$value}%")
                      ->orWhere('nin', 'like', "%{$value}%")
                      ->orWhere('email', 'like', "%{$value}%")
                      ->orWhere('phone', 'like', "%{$value}%");
                }
            });
            $queryParams['search'] = $search;
        }
    
        $clientsData = [];
        $clients = $clientsQuery->latest()->paginate(Helpers::pagination_limit())->appends($queryParams);
    
        // Loop through the clients and collect the required data
        foreach ($clients as $client) {
            $addedByUser = User::find($client->added_by); // Fetch the user who added this client
            
            $clientsData[] = [
                'client' => $client,
               'added_by_name' => $addedByUser ? $addedByUser->f_name . ' ' . $addedByUser->l_name : 'N/A',

            ];
        }
    
        return view('admin-views.clients.allClients', compact('clientsData', 'search', 'pageTitle', 'emptyMessage', 'clients'));
    }


    
    // active clients
     public function activeClients(Request $request): Factory|View|Application
        {
            
            
            
            
            // $this -> generateSanaaCardData();
        $pageTitle = 'Active Clients';
        $emptyMessage = 'No clients found';
    
        $queryParams = [];
        $search = $request->get('search');
        
        $clientsQuery = Client::where('status', 'active');
        
        if ($search) {
            $key = explode(' ', $search);
            $clientsQuery->where(function ($q) use ($key) {
                foreach ($key as $value) {
                    $q->orWhere('name', 'like', "%{$value}%")
                      ->orWhere('nin', 'like', "%{$value}%")
                      ->orWhere('email', 'like', "%{$value}%")
                      ->orWhere('phone', 'like', "%{$value}%");
                }
            });
            $queryParams['search'] = $search;
        }
    
        $clientsData = [];
        $clients = $clientsQuery->latest()->paginate(Helpers::pagination_limit())->appends($queryParams);
    
        // Loop through the clients and collect the required data
        foreach ($clients as $client) {
            $addedByUser = User::find($client->added_by); // Fetch the user who added this client
            
            $clientsData[] = [
                'client' => $client,
               'added_by_name' => $addedByUser ? $addedByUser->f_name . ' ' . $addedByUser->l_name : 'N/A',

            ];
        }
    
        return view('admin-views.clients.index', compact('clientsData', 'search', 'pageTitle', 'emptyMessage', 'clients'));
        }

    
    
 public function agentReport3333()
{
    $agents = User::join('clients', 'users.id', '=', 'clients.added_by')
        ->select(
            'users.id',
            'users.f_name',
            'users.l_name',
            \DB::raw('COUNT(clients.id) as client_count'),
            \DB::raw('SUM(clients.credit_balance) as total_money_out')
        )
        ->groupBy('users.id', 'users.f_name', 'users.l_name')
        ->get();

    // Initialize totals
    $totalClients = 0;
    $totalMoneyOut = 0;
    $totalAmountCollected = 0;
    $totalPerformance = 0;

    foreach ($agents as $agent) {
        // Calculate expected daily amount from total money out
        $agent->expected_daily = $agent->total_money_out / 30;

        // Calculate amount collected from cleared payment slots
        $agent->amount_collected = LoanPaymentInstallment::where('agent_id', $agent->id)
            ->where('status', 'cleared')
            ->sum('install_amount');

        // Calculate performance percentage
        if ($agent->expected_daily > 0) {
            $agent->performance_percentage = ($agent->amount_collected / ($agent->expected_daily * 30)) * 100;
        } else {
            $agent->performance_percentage = 0;
        }

        // Update totals
        $totalClients += $agent->client_count;
        $totalMoneyOut += $agent->total_money_out;
        $totalAmountCollected += $agent->amount_collected;
        $totalPerformance += $agent->performance_percentage;
    }

    // Calculate average performance
    $averagePerformance = count($agents) > 0 ? $totalPerformance / count($agents) : 0;

    // Pass totals to the view
    $totals = [
        'total_clients' => $totalClients,
        'total_money_out' => $totalMoneyOut,
        'total_amount_collected' => $totalAmountCollected,
        'average_performance' => $averagePerformance,
    ];

    return view('admin-views.reports.agent-report', compact('agents', 'totals'));
}

    
    
  

  
    
    
    public function distroy(Request $request)
    {
        
        
       $client = Client::findOrFail($request->id);
        $client->delete();
        Toastr::success(translate('Message Delete successfully'));
        
        // Redirect back to the client list with a success message
        return back(); //redirect()->route('admin.allclients');

    }


    
    // with balance
    public function clientsWithBalance()
{
    $pageTitle = 'Clients With Balance';
    $query = Client::where('credit_balance', '>', 0); // Updated to check credit_balance
    $emptyMessage = 'No Clients With Balance Yet';
    
    if (request()->search) {
        $query = $query->where('trx', request()->search);
        $emptyMessage = 'No Data Found';
    }
    
    $clients = $query->paginate(20);
    
    return view('admin-views.clients.index', compact('pageTitle', 'emptyMessage', 'clients'));
}


// banned
      public function bannedClients(Request $request): Factory|View|Application
        {
            $pageTitle = 'Banned Clients';
            $queryParams = [];
            $search = $request->input('search');
        
            $query = Client::where('status', 'banned');
            $emptyMessage = 'No Banned Clients Yet';
        
            if ($request->has('search')) {
                $query = $query->where('trx', 'like', "%{$search}%");
                $emptyMessage = 'No Data Found';
                $queryParams['search'] = $search;
            }
        
            $clients = $query->paginate(Helpers::pagination_limit())->appends($queryParams);
        
            return view('admin-views.clients.index', compact('pageTitle', 'emptyMessage', 'clients', 'search'));
        }

            
    // verified
    public function verifiedClients(Request $request): Factory|View|Application
                {
                    $pageTitle = 'Verified Clients';
                    $queryParams = [];
                    $search = $request->input('search');
                
                    $query = Client::where('verified', true);
                    $emptyMessage = 'No Verified Clients Yet';
                
                    if ($request->has('search')) {
                        $query = $query->where('trx', 'like', "%{$search}%");
                        $emptyMessage = 'No Data Found';
                        $queryParams['search'] = $search;
                    }
                
                    $clients = $query->paginate(Helpers::pagination_limit())->appends($queryParams);
                
                    return view('admin-views.clients.index', compact('pageTitle', 'emptyMessage', 'clients', 'search'));
                }




    /**
     * Store a newly created client in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
     
    //  get client profile 
   public function getClientProfile(Request $request): JsonResponse
    {
        $client = Client::where('id', $request -> id)->get();
        return response()->json(response_formatter(DEFAULT_200, $client, null), 200);
        
    }
     

    
    public function addClient(Request $request): JsonResponse
    {
        

        $client = Client::create($request->all());

        return response()->json(response_formatter(DEFAULT_200, $client, null), 200);

    }
    
    // get client guarantors
    public function clientguarantorsList(Request $request): JsonResponse
    {
        $clientguarantors = Guarantor::where('client_id', $request -> id)->get();
        return response()->json(response_formatter(DEFAULT_200, $clientguarantors, null), 200);
        
    }
    
  
    
    
    // add photos
    public function addClientPhotos(Request $request): JsonResponse
        {
            // Validate the request
            $request->validate([
                'client_id' => 'required|exists:clients,id',
                'photo' => 'nullable|file|mimes:jpeg,png,jpg',
                'national_id_photo' => 'nullable|file|mimes:jpeg,png,jpg',
            ]);
        
    
        
            $photoPath = $request->file('photo') ? $request->file('photo')->store('clients/photos', 'public') : null;
            $nationalIdPhotoPath = $request->file('national_id_photo') ? $request->file('national_id_photo')->store('clients/national_id_photos', 'public') : null;

            
            
            $client = Client::find($request->client_id);
        
            if ($client) {
                $client->client_photo = $photoPath;
                $client->national_id_photo = $nationalIdPhotoPath;
                $client->save();
            }
        
            // Return a JSON response with the updated client data
            return response()->json(response_formatter(DEFAULT_200, $client, null), 200);
        }

    
    
    
    
      public function updateProfile(Request $request): JsonResponse
    {
        $validator = Validator::make($request->all(), [
            'f_name' => 'required',
            'l_name' => 'required',
            'gender' => 'required',
            'occupation' => 'required'
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => Helpers::error_processor($validator)], 403);
        }

        $user = $this->user->find($request->user()->id);
        $user->f_name = $request->f_name;
        $user->l_name = $request->l_name;
        $user->email = $request->email;
        $user->image = $request->has('image') ? Helpers::update('customer/', $user->image, 'png', $request->image) : $user->image;
        $user->gender = $request->gender;
        $user->occupation = $request->occupation;
        $user->save();
        return response()->json(['message' => 'Profile successfully updated'], 200);
    }
    
   

}
