<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User; // Assuming agents are stored as users
use App\Models\Client;
use App\Models\LoanPayment;
use Carbon\Carbon;

class AgentReportController extends Controller
{
    /**
     * Display the report of a specific agent for a given day.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $agentId
     * @return \Illuminate\View\View
     */
     
    public function index1(Request $request, $agentId)
    {
         return view('admin-views.agent.agent');
    }

    
    public function index(Request $request, $agentId)
    {
        // Define the current date
        $today = Carbon::today();

        // Fetch the agent with their clients and loan payments for today
        $agent = User::with(['clients' => function ($query) use ($today) {
                $query->with(['loanPayments' => function ($paymentQuery) use ($today) {
                    $paymentQuery->whereDate('created_at', $today);
                }]);
            }])
            ->findOrFail($agentId);


        // Initialize counters and totals
        $totalClients = $agent->clients->count();
        $totalClientsPaid = 0;
        $totalClientsUnpaid = 0;
        $totalClientsAdvancePaid = 0;
        $totalLoanAmount = 0;
        $totalCollectedToday = 0;

        foreach ($agent->clients as $client) {
            $paymentsToday = $client->loanPayments;
            $totalPaidToday = $paymentsToday->sum('amount');
            $expectedPaymentToday = $client->expected_payment; // Ensure this field exists

            // Accumulate loan amounts (assuming client loan amount is stored in 'loan_amount')
            $totalLoanAmount += $client->loan_amount;

            // Calculate totals
            $totalCollectedToday += $totalPaidToday;

            if ($totalPaidToday >= $expectedPaymentToday && $totalPaidToday > 0) {
                $totalClientsPaid++;
            } elseif ($totalPaidToday > $expectedPaymentToday) {
                $totalClientsAdvancePaid++;
            } else {
                $totalClientsUnpaid++;
            }
        }

        // Pass data to the view
        return view('admin-views.agent.agent-report', compact(
            'agent',
            'totalClients',
            'totalClientsPaid',
            'totalClientsUnpaid',
            'totalClientsAdvancePaid',
            'totalLoanAmount',
            'totalCollectedToday'
        ));
    }
}
