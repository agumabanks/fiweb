<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Expense;
use App\Models\Cashflow;
use App\CentralLogics\helpers;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use App\Models\PaymentTransaction;

class ExpenseController extends Controller
{
   
    
   public function index()
{
    // Fetch all cashflows and expenses ordered by latest created_at
    $cashflows = Cashflow::orderBy('created_at', 'desc')->get();
    $expenses = Expense::orderBy('created_at', 'desc')->get();

    // Return the view with both data sets
    return view('admin-views.cashflow.index', compact('cashflows', 'expenses'));
}

        
          public function create()
            {
                // Fetch all cashflows and expenses
                // $cashflows = Cashflow::all();
                // $expenses = Expense::all();
            
                // Return the view with both data sets
                return view('admin-views.cashflow.addexpense');
            }


 public function createCashflow()
            {
                // Fetch all cashflows and expenses
                // $cashflows = Cashflow::all();
                // $expenses = Expense::all();
            
                // Return the view with both data sets
                return view('admin-views.cashflow.addcashflow');
            }

    /**
     * Store a new expense entry.
     */
    public function store(Request $request)
    {
        $request->validate([
            'description' => 'required|string|max:255',
            'amount' => 'required|numeric|min:0',
            'time' => 'required|date_format:Y-m-d\TH:i',
            'category' => 'nullable|string',
            'payment_method' => 'nullable|string',
            'notes' => 'nullable|string',
        ]);

        Expense::create([
            'transaction_id' => $this->generateTransactionId(), // Automatically generate the transaction ID
            'description' => $request->description,
            'amount' => $request->amount,
            'time' => date('Y-m-d H:i:s', strtotime($request->time)),
            'category' => $request->category,
            'payment_method' => $request->payment_method,
            'notes' => $request->notes,
            'added_by' => auth()->id(),
        ]);

        return redirect()->route('admin.expense.expenses')->with('success', 'Expense created successfully.');
    }

    /**
     * Store a new cashflow entry.
     */
public function storeCashflow(Request $request)
{
    // Validate the request data
    $request->validate([
        'balance_bf' => 'required|numeric',
        'capital_added' => 'required|numeric',
        'cash_banked' => 'required|numeric',
    ]);

    // Store the new cashflow record
    $cashflow = Cashflow::create([
        'balance_bf' => $request->input('balance_bf'),
        'capital_added' => $request->input('capital_added'),
        'cash_banked' => $request->input('cash_banked'),
    ]);

    // Redirect back with a success message
    return redirect()->route('admin.expense.expenses')->with('success', 'Cash flow created successfully.');
}



    /**
     * Edit an existing expense.
     */
    public function edit(Expense $expense)
    {
        return view('expenses.edit', compact('expense'));
    }

    /**
     * Update an expense entry.
     */
    public function update(Request $request, Expense $expense)
    {
        $request->validate([
            'description' => 'required|string|max:255',
            'amount' => 'required|numeric|min:0',
            'date' => 'required|date',
        ]);

        $expense->update($request->all());

        return redirect()->route('expenses.index')->with('success', 'Expense updated successfully.');
    }

    /**
     * Delete an expense entry.
     */
    public function destroy(Expense $expense)
    {
        $expense->delete();

        return redirect()->route('expenses.index')->with('success', 'Expense deleted successfully.');
    }

    /**
     * Generate a unique transaction ID for each transaction.
     */
    protected function generateTransactionId()
    {
        do {
            $transactionId = 'abROi' . mt_rand(1000000000, 9999999999);
        } while (Expense::where('transaction_id', $transactionId)->exists());

        return $transactionId;
    }

    /**
     * Handle cashflow record deletion.
     */
    public function destroyCashflow(Request $request)
    {
        $cashflow = Cashflow::findOrFail($request->id);
        $cashflow->delete();
        Toastr::success('Cashflow record deleted successfully.');

        return back();
    }
}
