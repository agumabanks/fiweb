<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MembershipController extends Controller
{
    public function createMembership(Request $request)
    {
        $request->validate([
            'user_id' => 'required|integer|exists:users,id',
            'membership_type' => 'required|string|in:Standard,Premium,Metal',
            'is_paid' => 'required|boolean',
        ]);

        $membership = Membership::create([
            'user_id' => $request->user_id,
            'membership_type' => $request->membership_type,
            'is_paid' => $request->is_paid,
        ]);

        return response()->json(['message' => 'Membership created successfully', 'membership' => $membership]);
    }

    public function updateMembershipPaymentStatus(Request $request, $id)
    {
        $request->validate([
            'is_paid' => 'required|boolean',
        ]);

        $membership = Membership::findOrFail($id);
        $membership->is_paid = $request->is_paid;
        $membership->save();

        return response()->json(['message' => 'Membership payment status updated successfully', 'membership' => $membership]);
    }

    public function getUserMembership($userId)
    {
        $membership = Membership::where('user_id', $userId)->firstOrFail();
        return response()->json(['membership' => $membership]);
    }
}
