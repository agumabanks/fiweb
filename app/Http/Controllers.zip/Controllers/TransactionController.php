<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaction;  
use Mike42\Escpos\Printer;
use Mike42\Escpos\PrintConnectors\WindowsPrintConnector;
use Mike42\Escpos\PrintConnectors\NetworkPrintConnector;
use Exception;
use App\Models\LoanPayment;
use App\Models\Client;


class TransactionController extends Controller
{
    /**
     * Display the transaction details.
     *
     * @param int $transactionId
     * @return \Illuminate\Http\Response
     */
    public function show($transactionId)
    {
        // Fetch the transaction details
        $transaction = LoanPayment::findOrFail($transactionId);

        return view('admin-views.transactions.show', compact('transaction'));
    }

    /**
     * Print the transaction receipt on a thermal printer.
     *
     * @param int $transactionId
     * @return \Illuminate\Http\JsonResponse 
     */
    public function printTransactionReceipt($transactionId)
    {
        try {
            // Fetch transaction details using the provided transaction ID
            $transaction = LoanPayment::find($transactionId);

            if (!$transaction) {
                throw new Exception("Transaction not found.");
            }

            // Choose the connector type based on your printer setup

            // Example for USB printer on Windows
            $connector = new WindowsPrintConnector("POS-58");

            // Example for network printer
            // $connector = new NetworkPrintConnector("192.168.0.100", 9100);

            // Initialize Printer
            $printer = new Printer($connector);

            // Print Header
            $printer->setTextSize(2, 2);
            $printer->text("Sanaa Finance\n");
            $printer->setTextSize(1, 1);
            $printer->text("Transaction Receipt\n");
            $printer->text("-----------------------------\n");

            // Print Transaction Details
            $printer->text("Transaction ID: " . $transaction->id . "\n");
            $printer->text("Date: " . $transaction->created_at->format('d M Y H:i:s') . "\n");
            $printer->text("Client: " . $transaction->client->name . "\n");
            $printer->text("Amount: UGX " . number_format($transaction->amount, 0) . "\n");
            $printer->text("Status: " . ucfirst($transaction->status) . "\n");
            $printer->text("-----------------------------\n");

            // Footer
            $printer->feed(2);
            $printer->cut();

            // Close printer connection
            $printer->close();

            return response()->json(['message' => 'Receipt printed successfully.']);
        } catch (Exception $e) {
            return response()->json(['error' => 'Could not print receipt: ' . $e->getMessage()], 500);
        }
    }
    
    
     /**
     * Print the full payment statement for a specific client on a thermal printer.
     *
     * @param int $clientId
     * @return \Illuminate\Http\JsonResponse
     */
     
     
     public function showStatment($clientId)
    {
        // Fetch the transaction details
            $client = Client::findOrFail($clientId);
            $payments = LoanPayment::where('client_id', $clientId)->get();

            return view('admin-views.transactions.statment', compact('client','payments'));
    }
    
    public function printClientPaymentStatement($clientId)
    {
        try {
            // Fetch all payments made by the client
            $payments = LoanPayment::where('client_id', $clientId)->get();

            if ($payments->isEmpty()) {
                throw new Exception("No payments found for this client.");
            }

            // Choose the connector type based on your printer setup
            $connector = new WindowsPrintConnector("POS-58");

            // Initialize Printer
            $printer = new Printer($connector);

            // Print Header
            $printer->setTextSize(2, 2);
            $printer->text("Sanaa Finance\n");
            $printer->setTextSize(1, 1);
            $printer->text("Client Payment Statement\n");
            $printer->text("-----------------------------\n");

            // Print Client Details
            $clientName = $payments->first()->client->name;
            $printer->text("Client: " . $clientName . "\n");
            $printer->text("-----------------------------\n");

            // Print Payment Details
            foreach ($payments as $payment) {
                $printer->text("Payment ID: " . $payment->id . "\n");
                $printer->text("Date: " . $payment->created_at->format('d M Y H:i:s') . "\n");
                $printer->text("Amount: UGX " . number_format($payment->amount, 0) . "\n");
                $printer->text("-----------------------------\n");
            }

            // Footer
            $printer->feed(2);
            $printer->cut();

            // Close printer connection
            $printer->close();

            return response()->json(['message' => 'Payment statement printed successfully.']);
        } catch (Exception $e) {
            return response()->json(['error' => 'Could not print payment statement: ' . $e->getMessage()], 500);
        }
    }
}
